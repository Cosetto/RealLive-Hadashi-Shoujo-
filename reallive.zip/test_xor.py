def xor_bytes(b1, b2):
    ret = b''
    for i in range(len(b1)):
        ret += (b1[i] ^ b2[i]).to_bytes(1, byteorder='little')
    return ret

def printHex(b):
	for i in b:
		print(f'{i:02X} ', end='')
	print('')

def main1():
    s1 = '9E AF 57 7E DB 4F 1D 3D 83 56 88 B6 62 11 BA 86' #truncate text
    s2 = 'EA 93 78 82 B5 82 A9 82 C8 82 A2 93 C1 95 CA 82' #Shift-jis hex
    b1 = bytes.fromhex(s1)
    b2 = bytes.fromhex(s2)
    printHex(b1)
    printHex(b2)
    xor_result = xor_bytes(b1, b2)
    printHex(xor_result)

def main2():
    s = '「ダンナ様、斗環は見つかっ'
    b = s.encode('cp932')
    printHex(b)

main1()
input("Press any key to exit...")

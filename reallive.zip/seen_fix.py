#Source: https://github.com/satan53x/SExtractor/blob/main/tools/RealLive
import os
import sys
from tkinter import filedialog

GameType = 2 # Choose game from XorTable
OffsetStart = 0x100 # 0x100 if extracted with arc_conv
DefaultDir = './Seen/'

XorTable = {
	# Hinasawa Tomoka no Zettai Joousei
	0: bytearray.fromhex('8A 03 CB 50 99 11 57 06 BD 68 D7 12 45 25 9C DC'),

	# Niizuma Tamaki ~Tamaki no Aisai Nikki + Harem End no Sorekara~
	1: bytearray.fromhex('83 0B CF 51 81 15 42 38 A0 67 DB 18 41 25 95 D4'),

	# Princess Heart Link ~Kenki-tachi no Enbu~ DL Edition
	2: bytearray.fromhex('83 0B CF 51 87 13 5F 6B 96 4D F6 14 4F 21 97 DE'),

	# Princess Heart Link ~Kenki-tachi no Enbu~ PKG Edition
	3: bytearray.fromhex('83 0B CF 51 87 13 5F 6B AE 68 D7 16 45 23 9B 87'),

    # 3Ping Lovers! ☆ Ippu Nisai no Sekai e Youkoso♪
    4: bytearray.fromhex('66 8A 20 D4 6E C3 B4 B8 4B F8 38 93 AC AC 70 0A'),

    # Niizuma Shino
    5: bytearray.fromhex('8C 03 CC 55 9F 1D 41 38 A1 60 D4 12 5D 2D 85 D4'),

    # Niizuma Koyomi
    6: bytearray.fromhex('80 05 D7 40 89 15 5D 3C A7 62 D3 17 41 39 86 D0'),

    # Lovedori Halation
    7: bytearray.fromhex('74 3C 2F FC 6E CD B4 BF 4B D4 2A 25 A3 84 70 04'),

    # Mizugi Shoujo to Biyaku Ice ~Zannen na Kanojo no Shitsukekata, Oshiemasu~
    8: bytearray.fromhex('93 02 CB 40 89 23 52 38 B0 7E D2 1A 5A 29 AD D1')
}

# Decrypt/Encrypt are the same
def fixSeenSub(data, tableType):
	pos = 0x20
	start = int.from_bytes(data[pos:pos+4], byteorder='little') + OffsetStart
	size = len(XorTable[tableType])
	for i in range(0x101):
		pos = start + i
		if pos >= len(data):
			break
		b = data[pos] ^ XorTable[tableType][i%size]
		data[pos] = b
	return data

def main(args):
	workpath = DefaultDir
	if os.path.isdir(workpath):
		pass
	elif len(args) > 1:
		workpath = args[1]
	else:
		workpath = filedialog.askdirectory(initialdir='.')
		if workpath == '': return
	print('Folder:', workpath)
	path = os.path.join(workpath, 'new')
	if not os.path.exists(path):
		os.makedirs(path)
	for name in os.listdir(workpath):
		if not name.endswith('.txt'): continue
		path = os.path.join(workpath, name)
		print('Original:', name)
		file = open(path, 'rb')
		data = bytearray(file.read())
		file.close()
		data = fixSeenSub(data, GameType)
		path = os.path.join(workpath, 'new', name)
		file = open(path, 'wb')
		file.write(data)
		file.close()
		print('New:', name)
	print('Done')

main(sys.argv)